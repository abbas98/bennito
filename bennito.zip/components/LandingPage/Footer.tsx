import React from 'react'

type Props = {}

export default function Footer({}: Props) {
  return (
    <div className='bg-[#2D3436] mt-10 w-full h-10  text-white flex justify-center items-center ltr'>© 2022 Bennito. All rights reserved.</div>
  )
}