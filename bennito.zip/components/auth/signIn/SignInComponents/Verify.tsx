import classNames from 'classnames'
import React, { useEffect, useRef, useState } from 'react'
import EnterSmsVerifyCode from './EnterSmsVerifyCode';
type Props = {}

export default function Verify({ }: Props) {

    /// hooks ////

    //// ////


    //// functions ////


    //// ////

    return (
        <div className='flex flex-col gap-10' >
            <EnterSmsVerifyCode />
        </div>
    )
}